<?php
session_start();
$_SESSION['welcome_popup_shown'] = true;